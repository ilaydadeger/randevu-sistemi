<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AnalysisController extends Controller
{
    public function analizEt(Request $request)
    {
        // 1. Formdan gelen tırnak fotoğrafını alıyoruz
        $resim = $request->file('tirnak_gorsel') ?? $request->file('design_image');

        if (!$resim) {
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json(['success' => false, 'message' => 'Lütfen bir fotoğraf yükleyin.'], 400);
            }
            return back()->with('error', 'Lütfen bir fotoğraf yükleyin.');
        }

        // 2. Fotoğrafı Python yapay zeka API'sine gönderiyoruz
        try {
            $response = Http::timeout(120)->attach(
                'file',
                file_get_contents($resim->path()),
                $resim->getClientOriginalName()
            )->post(config('services.ai.url') . '/analiz');

            if (!$response->successful()) {
                throw new \Exception('API yanıt vermedi (HTTP ' . $response->status() . ')');
            }
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('AI API Hatası: ' . $e->getMessage());
            
            $errorMessage = 'Yapay zeka servisi şu an ulaşılamıyor. Lütfen birkaç dakika sonra tekrar deneyin.';
            $statusCode = 503;

            // Eğer hata 429 (Too Many Requests) ise özel mesaj ver
            if (str_contains($e->getMessage(), 'HTTP 429')) {
                $errorMessage = 'Yapay zeka analiz limitine ulaştınız. Lütfen 1 dakika bekleyip tekrar deneyin.';
                $statusCode = 429;
            }

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => $errorMessage,
                    'debug_error' => $e->getMessage()
                ], $statusCode);
            }
            return back()->with('error', $errorMessage);
        }

        // 3. Python'dan gelen yanıtı çözümlüyoruz
        $veri = $response->json();

        // toplam_tirnak = görüntüde tespit edilen TÜM tırnak sayısı (temel + ekstra sanatlı)
        $gorunen_tirnak = $veri['toplam_tirnak'] ?? 0;
        // detaylar = sadece ekstra sanatlı tırnaklar: {"minimal_cizim": 2, "ombre": 1}
        $detaylar = $veri['detaylar'] ?? [];

        // 4. Tırnakçının veritabanındaki fiyatlarını çekiyoruz
        $nailTechId = $request->input('nail_tech_id', 1);
        $userPrices = \App\Models\UserPrice::where('artist_id', $nailTechId)
            ->join('service_categories', 'user_prices.service_category_id', '=', 'service_categories.id')
            ->select('service_categories.name', 'user_prices.price')
            ->get()
            ->pluck('price', 'name')
            ->toArray();

        // 5. Temel işlem fiyatları (Kalıcı Oje ve Jel Protez)
        $base_price_ko = $userPrices['Kalıcı Oje'] ?? 500;
        $base_price_jp = $userPrices['Jel Protez'] ?? 500;

        // 6. Ekstra sanat fiyatları — Python'ın sanat adını veritabanı adıyla eşleştiriyoruz
        // Tırnakçı bu fiyatları "Fiyatlarım" sayfasından girebilir, girmemişse varsayılanlar kullanılır
        $sanat_fiyat_haritasi = [
            'minimal_cizim' => $userPrices['Minimalist Çizim'] ?? 30,
            'ombre'         => $userPrices['French/Ombre']      ?? 40,
            'tas'           => $userPrices['3D Taş/Süsleme']    ?? 30,
            'hamur'         => $userPrices['3D Taş/Süsleme']    ?? 30,
            'detayli_cizim' => $userPrices['Detaylı Çizim']     ?? 50,
        ];

        // 7. Fotoğrafta görünen ekstra sanat maliyetini hesaplıyoruz
        // Örnek: 2 adet minimal_cizim × 30 TL + 1 adet ombre × 40 TL = 100 TL
        $gorunen_ekstra_maliyet = 0;
        $bulunan_sanat_detaylari = [];

        foreach ($detaylar as $sanat_adi => $adet) {
            if (isset($sanat_fiyat_haritasi[$sanat_adi])) {
                $birim_fiyat = $sanat_fiyat_haritasi[$sanat_adi];
                $toplam_sanat_fiyat = $birim_fiyat * $adet;
                $gorunen_ekstra_maliyet += $toplam_sanat_fiyat;
                $bulunan_sanat_detaylari[$sanat_adi] = [
                    'adet'        => $adet,
                    'birim_fiyat' => $birim_fiyat,
                    'toplam'      => $toplam_sanat_fiyat,
                ];
            }
        }

        // 8. 10 parmak tahmini ekstra maliyeti hesaplıyoruz
        // Görselde algılanan tüm benzersiz nail art kategorilerinin birim fiyatları toplanır ve 10 ile çarpılır.
        $toplam_birim_fiyat = 0;
        foreach ($detaylar as $sanat_adi => $adet) {
            if ($adet > 0 && isset($sanat_fiyat_haritasi[$sanat_adi])) {
                $toplam_birim_fiyat += $sanat_fiyat_haritasi[$sanat_adi];
            }
        }
        $on_parmak_tahmini_ekstra = $toplam_birim_fiyat * 10;

        // 9. Uzunluk ve Şekil fiyatlandırması (tırnakçı fiyatlandırmadan hariç bırakmadıysa)
        $user = \App\Models\User::find($nailTechId);
        $temel_detaylar = $veri['temel_detaylar'] ?? [];

        $detected_length = null;
        $detected_shape  = null;

        foreach ($temel_detaylar as $cls) {
            if (str_contains($cls, 'kisa'))         $detected_length = 'Kısa';
            elseif (str_contains($cls, 'normal'))   $detected_length = 'Orta';
            elseif (str_contains($cls, 'uzun'))     $detected_length = 'Uzun';

            if (str_contains($cls, 'badem'))        $detected_shape = 'Badem';
            elseif (str_contains($cls, 'stiletto')) $detected_shape = 'Stiletto';
            elseif (str_contains($cls, 'balerin'))  $detected_shape = 'Balerin';
            elseif (str_contains($cls, 'kare'))     $detected_shape = 'Kare';
        }

        $length_price = 0;
        $shape_price = 0;

        // 10. Nihai fiyatları hesaplıyoruz (Kalıcı Oje ve Jel Protez için ayrı ayrı)
        $toplam_ko = $base_price_ko + $on_parmak_tahmini_ekstra + $length_price + $shape_price;
        $toplam_jp = $base_price_jp + $on_parmak_tahmini_ekstra + $length_price + $shape_price;

        // 50'nin katlarına yuvarla (örn: 725 → 750, 751 → 800)
        $nihai_ko = (int) (ceil($toplam_ko / 50) * 50);
        $nihai_jp = (int) (ceil($toplam_jp / 50) * 50);

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success'             => true,
                'nihai_ko'            => $nihai_ko,
                'nihai_jp'            => $nihai_jp,
                'base_price_ko'       => $base_price_ko,
                'base_price_jp'       => $base_price_jp,
                'ekstra_tahmini'      => (int) round($on_parmak_tahmini_ekstra),
                'gorunen_tirnak'      => $gorunen_tirnak,
                'bulunan_sanatlar'    => $detaylar,
                'bulunan_sanat_detay' => $bulunan_sanat_detaylari,
                'detected_length'     => $detected_length,
                'detected_shape'      => $detected_shape,
                'length_price'        => $length_price,
                'shape_price'         => $shape_price,
            ]);
        }

        return view('frontend.sonuc', [
            'nihai_ko'         => $nihai_ko,
            'nihai_jp'         => $nihai_jp,
            'gorunen_tirnak'   => $gorunen_tirnak,
            'bulunan_sanatlar' => $detaylar
        ]);
    }
}
